
____________________________________________________________________________


Thank you for downloading a Planet Font!

____________________________________________________________________________

This Planet font is a PC TrueType font. It has a full character set in both 
upper- and lower case, full punctuation, most international characters, 
accents etc. and it contains an extensive kerning table.

All of the typefaces in the planet Font Family are CD-Ware and free for 
non-commercial use. That means, for each typeface you want to license for 
commercial use, you must mail us a CD with something you like: Music you 
have made, sounds you love, strange art or a peculiar piece of software... 
It can be a homebrew CD-R signed with a worn-out purple felt pen or a fancy 
commercial CD. No rules apply, but creativity is always appreciated :-)

Such a CD in our mailbox buys you a personal, non-transferable but 
everlasting license to use that typeface for commercial projects. We 
normally send electronic license confirmations within a couple of days 
after the receipt of a CD in our mailbox. Just remember to include your 
email address with the disc, so we know where to send the confirmation.

If you like what you did with our fonts, you are more than welcome to send a 
copy, a screenshot or a scan of the product back to us. We are always eager 
to see how people use the fonts, and we're collecting examples for future 
publishing on the web.

Kind regards

Mads Rydahl

____________________________________________________________________________

     P l a n e t

     multimedia design studio 
____________________________________________________________________________

     Humlevej 26 
     DK-8240 Risskov
     Denmark

     Company site: http://www.planet.dk 
     Company mail: mailto:beam@planet.dk

____________________________________________________________________________

This Planet Font is copyright (c) 1996 by Mads Rydahl, All Rights Reserved.  
It is distributed free, provided all files in this archive (including this 
text ducument) are included.  User groups and shareware/public domain 
outlets may distribute the font under these contitions, provided that credit 
is given next to the font or next to any link to the font. This credit shall 
take the form of a clearly readable text stating the name of the designer 
and a link to The Planet website at http://www.planet.dk/. 
____________________________________________________________________________
